package org.vosk

actual class IOException actual constructor(message: String?) : Exception()